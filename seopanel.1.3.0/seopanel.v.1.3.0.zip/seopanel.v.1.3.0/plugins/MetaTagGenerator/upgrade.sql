ALTER TABLE `metatag` ADD `key` INT NOT NULL;
