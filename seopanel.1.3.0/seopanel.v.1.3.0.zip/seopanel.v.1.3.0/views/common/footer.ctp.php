<div id="footer">
<div>&#169; Copyright 2010-2020	www.seopanel.in All rights reserved.</div>
<div>
	<a href="http://www.seopanel.in/" target="_blank">SEO PANEL</a> | 
	<a href="http://support.seofreetools.net/" target="_blank">SEO PANEL SUPPORT</a> |
	<a href="http://www.seofreetools.net/seo-tools/" target="_blank">SEO TOOLS</a> | 
	<a href="http://www.seofreetools.net/seo-tutorials/" target="_blank">SEO TUTORIALS</a> | 
	<a href="http://www.seofreetools.net/seo-news/" target="_blank">SEO NEWS</a> | 
	<a href="http://www.seopanel.in/contact/" target="_blank">CONTACT US</a> |  
	<a href="http://www.gethostingplans.com/" target="_blank">WEB HOSTING PLANS</a> | 
	<a href="http://directory.seofreetools.net/" target="_blank">SEO FREE DIRECTORY</a>
</div>
</div>
