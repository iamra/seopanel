<div id='topnewsbox'>
	<div id="newscontbox"><?php echo $newsContent;?></div>
	<div id="closebox"><a href="javascript:void(0);" onclick="hideNewsBox('newsalert','hidenews','1')"><img src="<?=SP_IMGPATH?>/btnCloseX.gif"></a></di>
</div>
