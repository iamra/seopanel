<div class="Center" style='width:100%;'>
<div class="col" style="padding-left:8px;">
<div class="Block">
<table width="100%" border="0" cellspacing="0px" cellpadding="0">
	<tr>
		<td align="center">
		<p class="dirmsg" style="height: 20px;padding:5px;">
			<font class="error" style="font-size: 13px;"><?=$msg?></font>
		</p>
		</td>
	</tr>
</table>

</div>
</div>
</div>
