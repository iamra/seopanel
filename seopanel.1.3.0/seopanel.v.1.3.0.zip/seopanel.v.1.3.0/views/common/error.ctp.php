<div id='subcontent'>
	<p class='note error'><?php echo $errorMsg;?></p>
</div>