<tr class="blue_row">
	<td class="tab_left_bot_noborder">&nbsp;</td>
	<td class="td_bottom_border" colspan="<?=$colspan?>"><?=$msg?></td>
	<td class="tab_right_bot">&nbsp;</td>
</tr>
