<div class="Center" style='width:100%;'>
<div class="col" style="">
<div class="SectionHeader">
<h1 style="text-align:center;">Seo Panel Support System</h1>
</div>
<div class="Block">
<h1 class="BlockHeader">&nbsp;</h1>
<br />
<div>
<h1>Seo Panel support system will provide you following services.</h1>
<p style="font-size: 13px;">
	
	<p>a) <a><b>1000 Directory Package</b></a> - To add 1000 free internet directories to your seo panel directory submission tool. It will help you to increase the backlinks and site rank.</p>
	<p>b) <a><b>New Search Engines</b></a> - To add new search engines(eg:baidu.com) to your seo panel keyword position checker.</p>
	<p>c) <a><b>New Seo Tools</b></a> - To create new seo tools suitable for your buisiness in seo panel.</p>
	<p>d) <a><b>New Seo Plugins</b></a> - To create new seo plugins suitable for your buisiness in seo panel.</p>	
	<p>e) <a><b>New Skin</b></a> - To add new skin to seo panel for your buisiness needs.</p>
	<p>f) <a><b>Customization</b></a> - To customize the seo panel tools,plugins and features for your buisiness needs.</p>
	<p>g) <a><b>Report Bugs</b></a> - To report new bugs about seo panel tools,plugins and features.</p>
	<p>g) <a><b>Support Tickets</b></a> - To get technical support from seo panel team to setup the seo panel. Eg: To set up cron for keyword position checker.</p>
	
	<p><a href="http://support.seofreetools.net/" target="_blank" title="seo panel support"><img src="<?=SP_IMGPATH?>/submit_ticket.jpg" alt="seo panel support"></a> or Please <a href="http://support.seofreetools.net/" target="_blank" title="seo panel support"><b>click here</b></a> to create new tickets in <b>seo panel support system</b>.</p>	 
</p>
</div>

</div>
</div>
</div>
