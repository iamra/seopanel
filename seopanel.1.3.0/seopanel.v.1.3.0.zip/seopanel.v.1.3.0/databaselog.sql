--
--This file includes the database changes of Seo Panel version from 1.2.0 to 1.3.0
--

--
-- Table structure for table `saturationresults`
--

CREATE TABLE IF NOT EXISTS `saturationresults` (
  `website_id` int(11) NOT NULL,
  `google` int(11) NOT NULL,
  `yahoo` int(11) NOT NULL,
  `msn` int(11) NOT NULL,
  `result_time` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



--
-- Table structure for table `seotools`
--

DROP TABLE IF EXISTS `seotools`;
CREATE TABLE IF NOT EXISTS `seotools` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url_section` varchar(100) NOT NULL,
  `reportgen` tinyint(1) NOT NULL DEFAULT '1',
  `cron` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `seotools`
--

INSERT INTO `seotools` (`id`, `name`, `url_section`, `reportgen`, `cron`, `status`) VALUES
(1, 'Keyword Position Checker', 'keyword-position-checker', 1, 1, 1),
(2, 'Sitemap Generator', 'sitemap-generator', 0, 0, 1),
(3, 'Rank Checker', 'rank-checker', 1, 1, 1),
(4, 'Backlinks Checker', 'backlink-checker', 1, 1, 1),
(5, 'Directory Submission', 'directory-submission', 1, 1, 1),
(6, 'Search Engine Saturation', 'saturation-checker', 1, 1, 1);


--
-- New column for users table
--
ALTER TABLE `users` ADD `created` INT( 11 ) NOT NULL AFTER `email`;
Update `users` set created=UNIX_TIMESTAMP() WHERE created=0;


--
-- New column for Seo Plugins table
--
ALTER TABLE `seoplugins` ADD `author` VARCHAR( 64 ) NOT NULL AFTER `name` ,
ADD `description` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL AFTER `author` ,
ADD `version` VARCHAR( 8 ) NOT NULL AFTER `description` ,
ADD `website` VARCHAR( 255 ) NOT NULL AFTER `version`; 
 
