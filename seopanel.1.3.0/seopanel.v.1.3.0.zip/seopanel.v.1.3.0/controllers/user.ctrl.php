<?php

/***************************************************************************
 *   Copyright (C) 2009-2011 by Geo Varghese(www.seopanel.in)  	   *
 *   sendtogeo@gmail.com   												   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

# class defines all user controller functions
class UserController extends Controller{	
	
	# index function
	function index(){
		$this->render('common/login');
	}
	
	# login function
	function login(){
		$this->set('post', $_POST);
		$errMsg['userName'] = formatErrorMsg($this->validate->checkBlank($_POST['userName']));
		$errMsg['password'] = formatErrorMsg($this->validate->checkBlank($_POST['password']));
		if(!$this->validate->flagErr){
			$sql = "select u.*,ut.user_type from users u,usertypes ut where u.utype_id=ut.id and u.username='".$this->db->escapeMysqlString($_POST['userName'])."'";
			$userInfo = $this->db->select($sql, true);
			if(!empty($userInfo['id'])){
				if($userInfo['password'] == md5($_POST['password'])){
					if($userInfo['status'] == 1){
						$uInfo['userId'] = $userInfo['id'];
						$uInfo['userType'] = $userInfo['user_type']; 
						Session::setSession('userInfo', $uInfo);
						redirectUrl(SP_WEBPATH."/");
					}else{
						$errMsg['userName'] = formatErrorMsg("User inactive");
					}
				}else{
					$errMsg['password'] = formatErrorMsg("Password incorrect");
				}
			}else{
				$errMsg['userName'] = formatErrorMsg("Login incorrect");
			}
		}
		$this->set('errMsg', $errMsg);
		$this->index();
	}
	
	# function for logout
	function logout(){
		Session::setSession('userInfo', "");
		redirectUrl(SP_WEBPATH."/login.php");
	}
	
	# func to show users
	function listUsers($layout='default'){
		$this->set('sectionHead', 'User Manager');		
		$sql = "select * from users where utype_id=2 order by username";
		
		# pagination setup		
		$this->db->query($sql, true);
		$this->paging->setDivClass('pagingdiv');
		$this->paging->loadPaging($this->db->noRows, SP_PAGINGNO);
		$pagingDiv = $this->paging->printPages('users.php', '', 'scriptDoLoad', 'ContentFrame', 'layout=ajax');		
		$this->set('pagingDiv', $pagingDiv);
		$sql .= " limit ".$this->paging->start .",". $this->paging->per_page;
		
		$userList = $this->db->select($sql);
		$this->set('userList', $userList);		
		$this->render('user/list', $layout);
	}
	
	# func to change status
	function __changeStatus($userId, $status){
		$sql = "update users set status=$status where id=$userId";
		$this->db->query($sql);
		
		# deaactivate all websites under this user
		if(empty($status)){
			$websiteCtrler = New WebsiteController();
			$websiteList = $websiteCtrler->__getAllWebsites($userId);
			foreach ($websiteList as $websiteInfo){
				$websiteCtrler->__changeStatus($websiteInfo['id'], 0);
			}
		}
	}
	
	# func to change status
	function __deleteUser($userId){
		$sql = "delete from users where id=$userId";
		$this->db->query($sql);
		
		$sql = "select id from websites where user_id=$userId";
		$webisteList = $this->db->select($sql);
		$webisteCtrler = New WebsiteController();
		foreach($webisteList as $webisteInfo){
			$webisteCtrler->__deleteWebsite($webisteInfo['id']);
		}
	}
	
	function newUser(){		
		$this->set('sectionHead', 'New User');				
		$this->render('user/new', 'ajax');
	}
	
	function __checkUserName($username){
		$sql = "select id from users where username='$username'";
		$userInfo = $this->db->select($sql, true);
		return empty($userInfo['id']) ? false :  $userInfo['id'];
	}
	
	function __checkEmail($email){
		$sql = "select id from users where email='$email'";
		$userInfo = $this->db->select($sql, true);
		return empty($userInfo['id']) ? false :  $userInfo['id'];
	}
	
	function __getUserInfo($userId){
		$sql = "select * from users where id=$userId";
		$userInfo = $this->db->select($sql, true);
		return empty($userInfo['id']) ? false :  $userInfo;
	}
	
	/*
	 * function to get all users
	 */
	function __getAllUsers($active=1,$admin=true){
		$sql = "select * from users where status=$active";
		$sql .= $admin ? "" : " and utype_id!=1";
		$sql .= " order by username"; 
		$userList = $this->db->select($sql);
		return $userList;
	}
	
	function createUser($userInfo){
		$this->set('post', $userInfo);
		$errMsg['userName'] = formatErrorMsg($this->validate->checkUname($userInfo['userName']));
		$errMsg['password'] = formatErrorMsg($this->validate->checkPasswords($userInfo['password'], $userInfo['confirmPassword']));
		$errMsg['firstName'] = formatErrorMsg($this->validate->checkBlank($userInfo['firstName']));
		$errMsg['lastName'] = formatErrorMsg($this->validate->checkBlank($userInfo['lastName']));
		$errMsg['email'] = formatErrorMsg($this->validate->checkEmail($userInfo['email']));
		if(!$this->validate->flagErr){
			if (!$this->__checkUserName($userInfo['userName'])) {
				if (!$this->__checkEmail($userInfo['email'])) {
					$sql = "insert into users(id,utype_id,username,password,first_name,last_name,email,created,status) 
							values('',2,'{$userInfo['userName']}','".md5($userInfo['password'])."','{$userInfo['firstName']}','{$userInfo['lastName']}','{$userInfo['email']}',UNIX_TIMESTAMP(),1)";
					$this->db->query($sql);
					$this->listUsers('ajax');
					exit;
				}else{
					$errMsg['email'] = formatErrorMsg('Email already exist!');
				}
			}else{
				$errMsg['userName'] = formatErrorMsg('Username already exist!');
			}
		}
		$this->set('errMsg', $errMsg);
		$this->newUser();
	}
	
	function editUser($userId, $userInfo=''){		
		$this->set('sectionHead', 'Edit User');
		if(!empty($userId)){
			if(empty($userInfo)){
				$userInfo = $this->__getUserInfo($userId);
				$userInfo['userName'] = $userInfo['username'];
				$userInfo['firstName'] = $userInfo['first_name'];
				$userInfo['lastName'] = $userInfo['last_name'];
				$userInfo['oldName'] = $userInfo['username'];
				$userInfo['oldEmail'] = $userInfo['email'];
			}
			
			$userInfo['password'] = '';					
			$this->set('post', $userInfo);			
			$this->render('user/edit', 'ajax');
			exit;
		}
		$this->listUsers('ajax');		
	}
	
	function updateUser($userInfo){
		$this->set('post', $userInfo);
		$errMsg['userName'] = formatErrorMsg($this->validate->checkUname($userInfo['userName']));
		if(!empty($userInfo['password'])){
			$errMsg['password'] = formatErrorMsg($this->validate->checkPasswords($userInfo['password'], $userInfo['confirmPassword']));
			$passStr = "password = '".md5($userInfo['password'])."',";
		}
		$errMsg['firstName'] = formatErrorMsg($this->validate->checkBlank($userInfo['firstName']));
		$errMsg['lastName'] = formatErrorMsg($this->validate->checkBlank($userInfo['lastName']));
		$errMsg['email'] = formatErrorMsg($this->validate->checkEmail($userInfo['email']));
		if(!$this->validate->flagErr){
			
			if($userInfo['userName'] != $userInfo['oldName']){
				if ($this->__checkUserName($userInfo['userName'])) {
					$errMsg['userName'] = formatErrorMsg('Username already exist!');
					$this->validate->flagErr = true;
				}
			}
			
			if($userInfo['email'] != $userInfo['oldEmail']){
				if ($this->__checkEmail($userInfo['email'])) {
					$errMsg['email'] = formatErrorMsg('Email already exist!');
					$this->validate->flagErr = true;
				}
			}
			
			if (!$this->validate->flagErr) {
				$sql = "update users set
						username = '{$userInfo['userName']}',
						first_name = '{$userInfo['firstName']}',
						last_name = '{$userInfo['lastName']}',
						$passStr
						email = '{$userInfo['email']}'
						where id={$userInfo['id']}";
				$this->db->query($sql);
				$this->listUsers('ajax');
				exit;
			}
		}
		$this->set('errMsg', $errMsg);
		$this->editUser($userInfo['id'], $userInfo);
	}
	
	function showMyProfile($userInfo=''){
		$userId = isLoggedIn();		
		$this->set('sectionHead', 'Edit My profile');
		if(!empty($userId)){
			if(empty($userInfo)){
				$userInfo = $this->__getUserInfo($userId);
				
				$userInfo['userName'] = $userInfo['username'];
				$userInfo['firstName'] = $userInfo['first_name'];
				$userInfo['lastName'] = $userInfo['last_name'];
				$userInfo['oldName'] = $userInfo['username'];
				$userInfo['oldEmail'] = $userInfo['email'];
			}
			
			$userInfo['password'] = '';					
			$this->set('post', $userInfo);			
			$this->render('user/editmyprofile', 'ajax');
			exit;
		}	
	}
	
	function updateMyProfile($userInfo){
		$this->set('post', $userInfo);
		$errMsg['userName'] = formatErrorMsg($this->validate->checkUname($userInfo['userName']));
		if(!empty($userInfo['password'])){
			$errMsg['password'] = formatErrorMsg($this->validate->checkPasswords($userInfo['password'], $userInfo['confirmPassword']));
			$passStr = "password = '".md5($userInfo['password'])."',";
		}
		$errMsg['firstName'] = formatErrorMsg($this->validate->checkBlank($userInfo['firstName']));
		$errMsg['lastName'] = formatErrorMsg($this->validate->checkBlank($userInfo['lastName']));
		$errMsg['email'] = formatErrorMsg($this->validate->checkEmail($userInfo['email']));
		if(!$this->validate->flagErr){
			
			if($userInfo['userName'] != $userInfo['oldName']){
				if ($this->__checkUserName($userInfo['userName'])) {
					$errMsg['userName'] = formatErrorMsg('Username already exist!');
					$this->validate->flagErr = true;
				}
			}
			
			if($userInfo['email'] != $userInfo['oldEmail']){
				if ($this->__checkEmail($userInfo['email'])) {
					$errMsg['email'] = formatErrorMsg('Email already exist!');
					$this->validate->flagErr = true;
				}
			}
			
			if (!$this->validate->flagErr) {
				$sql = "update users set
						username = '{$userInfo['userName']}',
						first_name = '{$userInfo['firstName']}',
						last_name = '{$userInfo['lastName']}',
						$passStr
						email = '{$userInfo['email']}'
						where id={$userInfo['id']}";
				$this->db->query($sql);
				$this->set('msg', 'Saved My Profile Details');
				$this->showMyProfile();
				exit;
			}
		}
		$this->set('errMsg', $errMsg);
		$this->showMyProfile($userInfo);
	}
}
?>