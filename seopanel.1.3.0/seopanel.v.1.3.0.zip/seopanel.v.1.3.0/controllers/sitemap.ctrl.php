<?php

/***************************************************************************
 *   Copyright (C) 2009-2011 by Geo Varghese(www.seopanel.in)  	   *
 *   sendtogeo@gmail.com   												   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

# class defines all sitemap controller functions
class SitemapController extends Controller{

	var $smLimit = 50000;			# number of pages in a sitemap
 	var $baseUrl;					# base url of page
 	var $smType='xml';				# the type of sitemap file should be created
 	var $urlList;					# the list of urls crawled from a site
 	var $hostName;					# hostname of the site
 	var $spider;					# spider object
 	var $sleep = 0;					# sleep b/w the page crawl in seconds
 	var $excludeUrl = "";			# url to be excluded
 	var $changefreq = "always";		# page modification frequency
 	var $priority = 0.5;			# priority of a page
 	var $lastmod;				 	# page last modification date
 	var $smheader;					# sitemap header
 	var $smfooter;					# sitemap footer
 	var $smfile = "";				# sitemap file
 	var $section = "";              # sitemap website
	
	# func to show sitemap generator interface
	function showSitemapGenerator() {
		$this->set('sectionHead', 'Sitemap Generator');
		$userId = isLoggedIn();
		
		$websiteController = New WebsiteController();
		$websiteList = $websiteController->__getAllWebsites($userId, true);
		$this->set('websiteList', $websiteList);
		$websiteId = empty ($searchInfo['website_id']) ? $websiteList[0]['id'] : $searchInfo['website_id'];
		$this->set('websiteId', $websiteId);
		
		$this->render('sitemap/showsitemap');
	}	
	
	# func to generate sitemap
 	function generateSitemapFile($sitemapInfo){
 		if(!empty($sitemapInfo['website_id'])){ 			
			setcookie("url_count", 0);
			setcookie("curr_url", '');			
			$websiteController = New WebsiteController();
			$websiteInfo = $websiteController->__getWebsiteInfo($sitemapInfo['website_id']);
 			$baseUrl = $websiteInfo['url'];
 			$this->section = formatFileName($websiteInfo['name']);
			
 			if(!preg_match('/\/$/', $baseUrl)) $baseUrl = $baseUrl."/";
			$this->baseUrl = $baseUrl;
			$urlInfo = parse_url($this->baseUrl);
			$this->hostName = str_replace('www.', '', $urlInfo['host']);
			$this->smType = $sitemapInfo['sm_type'];
			$this->excludeUrl = $sitemapInfo['exclude_url'];
			if(!empty($sitemapInfo['freq'])) $this->changefreq = $sitemapInfo['freq'];
			if(!empty($sitemapInfo['priority'])) $this->priority = $sitemapInfo['priority'];
			
			$this->createSitemap();
 		}else{
 			echo "<p class='note notefailed'>No Website Found.</p>";
 		} 		
 	}
 	
 	# Create new sitemaps and index file 	
 	function createSitemap($smType="", $urlList="") {
 		
 		if(!empty($smType)){
 			$this->smType = $smType;
 		} 		
 		
 		# func call to crawl urls from site
 		if(empty($urlList)){
 			setcookie("url_count", 0);
			setcookie("curr_url", $this->baseUrl);
			$this->getSitemapUrls();
 		}else{
 			$this->urlList = $urlList;
 		}		
 		
 		print("<p class=\"note noteleft\">Found <a>".count($this->urlList)."</a> Sitemap Urls</p>"); 		
 		$function = $this->smType ."SitemapFile";
 		$this->deleteSitemapFiles();
 		$this->$function(array_keys($this->urlList));
 		$this->showSitemapFiles();
 		
	}
	
	# func to get a sitemap urls of a site
	function getSitemapUrls(){		
		$this->urlList = array();
		$this->crawlSitemapUrls($this->baseUrl, true);						
	}
	
	# func to crawl sitemap urls
	function crawlSitemapUrls($baseUrl, $recursive=false){
		
		if($this->urlList[$baseUrl]['visit'] == 1) return;				
		$this->urlList[$baseUrl]['visit'] = 1;
		
		setcookie("url_count", count($this->urlList));
		setcookie("curr_url", $baseUrl);
		
		$urlList = $this->spider->getUniqueUrls($baseUrl);
		$hostName = $this->hostName;
		
		foreach($urlList as $href){
			if(preg_match('/\.zip$|\.gz$|\.tar$/', $href)) continue;
			$urlInfo = @parse_url($href);
			
			$urlHostName = str_replace('www.', '', $urlInfo['host']);
			if(empty($urlHostName)){
				$href = $this->baseUrl.$href;
			}else{
				if($urlHostName != $hostName){
					continue;
				}
			}
			
			$href = $this->spider->formatUrl($href);
			$href = preg_replace('/http:\/\/.*?\//i', $this->baseUrl, $href);
			if(!empty( $this->excludeUrl) && stristr($href, $this->excludeUrl)) continue;
			if(!isset($this->urlList[$href]['visit']) && !isset($this->urlList[$href.'/']['visit'])){
				$this->urlList[$href]['visit'] = 0;
				if($recursive){
					sleep($this->sleep);
					$this->crawlSitemapUrls($href,true);
				}
			}
		}			
	}

	# create text sitemap file
	function txtSitemapFile($urlList) {
		$this->smheader = '';	
		$this->smfooter = '';
		$smxml = "";
		foreach($urlList as $this->loc){
			$smxml .= $this->loc ."\n";
		}
		$this->smfile = $this->section ."_sitemap1.".$this->smType;
		$this->createSitemapFile($smxml);
	}
	
	# create Html sitemap file
	function htmlSitemapFile($urlList) {
		$this->smheader = '';	
		$this->smfooter = '';
		$smxml = "";
		foreach($urlList as $this->loc){
			$smxml .= "<a href='$this->loc'>$this->loc</a><br>";
		}
		$this->smfile = $this->section ."_sitemap1.".$this->smType;
		$this->createSitemapFile($smxml);
	}
	
	
	# create xml sitemap file
	function xmlSitemapFile($urlList) {
		$this->lastmod = Date("Y-m-d");
		$this->smheader = '<?xml version="1.0" encoding="UTF-8"?>
		<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
		xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
		xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
		http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd"><!-- created with Seo Panel:www.seopanel.in -->';	
		$this->smfooter = '</urlset>';
		$index = 1;
		$rowcount = 0;
		$smxml = "";
			
		foreach($urlList as $this->loc){
			$smxml .= $this->createUrlXmlText();
			if(($this->smLimit -1) == $rowcount++){
				
				# create sitemap file when tot url count equal max count
				$this->smfile = $this->section ."_sitemap". $index . ".".$this->smType;
				$this->createSitemapFile($smxml);
				$rowcount = 0;
				$smxml = "";
				$index++;				
			}
		}
			
		# to create sitemap file with rest of urls 
		if(!empty($smxml)){
			$this->smfile = $this->section ."_sitemap". $index . ".xml";
			$this->createSitemapFile($smxml);
		}		
	}	
	
	function showSitemapFiles(){
		if ($handle = opendir(SP_TMPPATH ."/sitemap/")) {
		    while (false !== ($file = readdir($handle))) {
		        if ( ($file != ".") && ($file != "..") ) {
		        	if(preg_match("/".$this->section."_sitemap\d+\.".$this->smType."/", $file, $matches)){
		        		echo "<p class=\"note noteleft\">
		        				Download sitemap file from: 
		        				<a href='".SP_WEBPATH."/download.php?filesec=sitemap&filetype=$this->smType&file=".urlencode($matches[0])."' target='_blank'>$file</a>
		        			</p>";
		        	}
		        }
		    }
		    closedir($handle);
		}
	}
	
	function deleteSitemapFiles(){
		if ($handle = opendir(SP_TMPPATH ."/sitemap/")) {
		    while (false !== ($file = readdir($handle))) {
		        if ( ($file != ".") && ($file != "..") ) {
		        	if(preg_match("/".$this->section."_sitemap\d+\.".$this->smType."/", $file, $matches)){
		        		unlink(SP_TMPPATH ."/sitemap/".$file);
		        	}
		        }
		    }
		    closedir($handle);
		}
	}
	
	# create url xml text 
	function createUrlXmlText() {		
		$xmltext = 
		'
		<url>
			<loc>'.$this->loc.'</loc>
		   	<lastmod>'.$this->lastmod.'</lastmod>
		    <changefreq>'.$this->changefreq.'</changefreq>
		    <priority>'.$this->priority.'</priority>
	 	</url>
	 	';
	 	return $xmltext;
	}
	
	# create sitemap file
	function createSitemapFile($smxml) {
		$fp = fopen(SP_TMPPATH ."/sitemap/" .$this->smfile, 'w');
		$smxml = $this->smheader . $smxml . $this->smfooter; 
		fwrite($fp, $smxml);
		fclose($fp);
	}
	
	
	# function to create encoded url for sitemap
	function getEncodedUrl($url){
		
		# convert url to entity encoded
		$url = str_replace(array('&',"'",'"','>','<'," "), array('&amp;','&apos;','&quot;','&gt;','&lt;','_'), $url);
		return $url;
	}
		
}
?>